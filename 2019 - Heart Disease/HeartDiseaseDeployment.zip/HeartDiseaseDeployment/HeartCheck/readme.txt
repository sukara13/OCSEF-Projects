run Anaconda Prompt
cd \HeartCheck
set FLASK_APP=heartXGB_WS.py
flask run --host 198.12.149.165 --port 8080
